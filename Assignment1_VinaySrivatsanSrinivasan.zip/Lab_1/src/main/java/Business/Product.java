/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import javax.swing.ImageIcon;

/**
 *
 * @author admin
 */
public class Product {
    private String name;
    private String price;
    private String model;
    private String colour;
    private String mileage;
    private String engine;
    private String transmission;
    private String fuelType;
    private String seatingCapacity;
    private String variant;
    private String centralLocking;
    private String PowerWindows;
    private String ABS;
    private String fogLamp;
    private String Airbags;
    private ImageIcon img;

    public ImageIcon getImg() {
        return img;
    }

    public void setImg(ImageIcon img) {
        this.img = img;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getMileage() {
        return mileage;
    }

    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getSeatingCapacity() {
        return seatingCapacity;
    }

    public void setSeatingCapacity(String seatingCapacity) {
        this.seatingCapacity = seatingCapacity;
    }

    public String getVariant() {
        return variant;
    }

    public void setVariant(String variant) {
        this.variant = variant;
    }

    public String getCentralLocking() {
        return centralLocking;
    }

    public void setCentralLocking(String centralLocking) {
        this.centralLocking = centralLocking;
    }

    public String getPowerWindows() {
        return PowerWindows;
    }

    public void setPowerWindows(String PowerWindows) {
        this.PowerWindows = PowerWindows;
    }

    public String getABS() {
        return ABS;
    }

    public void setABS(String ABS) {
        this.ABS = ABS;
    }

    public String getFogLamp() {
        return fogLamp;
    }

    public void setFogLamp(String fogLamp) {
        this.fogLamp = fogLamp;
    }

    public String getAirbags() {
        return Airbags;
    }

    public void setAirbags(String Airbags) {
        this.Airbags = Airbags;
    }
    
}
